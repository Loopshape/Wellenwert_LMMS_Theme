WELLENWERT – LMMS THEME
-----------------------

I've taken on of the dark-themes from the LMMS-website and changed some color informations of the theme-palette.
Just copy the content of the inner ZIP-archiv into the default-folder within "/usr/share/lmms/themes". 
Restart LMMS, there'ya go!!!

Greetings, 
Loopshape aka. "Wellenwert"


ps: Take a look in the Screenshot...


---
The modified Wellenwert-Theme is based on some multiple uploads, that were put together and recolored: 
https://lmms.io/lsp/?action=show&file=11356